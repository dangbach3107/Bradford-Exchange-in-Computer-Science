#1
print('Exercise 1')
print("+----+")
for i in range(3):
    print("\\    /")
    print("/    \\") 
print("+----+")
#2
print('Exercise 2')
for i in range(5):
    print("*"*10)
#3b
print('Exercise 3b')
for i in range(1,7):
    print(2*i)
#4
print('Exercise 4')
for i in range(1,8):
      print(str(i)*i)
#5
print('Exercise 5')
def pay(x,y):
    if y<=8:
        return x*y
    else:
        return x*8 + x*1.5*(y-8)
print(pay(4,11))
#6
print('Exercise 6')
import math
def area(radius):
    return math.pi * radius* radius
print(area(2))
#7
print('Exercise 7')
low = int(input("Enter the lowers counter no"))
high = int(input("Enter the highes counter no"))
sum = 0
for i in range(low,high):
    sum += i
print("sum = " , sum)
#8
print('Exercise 8')
sum=0
inputnum = int(input('Enter a positive number:'))
while inputnum != 0:
     sum=sum+inputnum
     inputnum=int(input('Enter a positive number:') )
print('The sum of the numbers entered ',sum)
#10
print('Exercise 10')
def repl(s, n):
    return s*n
print(repl("hello", 3))
#11
print('Exercise 11')
def printRange(x,y):
    while x!=y:
        print(x, end=' ')
        if x < y:
            x+=1
        else:
            x-=1
    print (y)
printRange(2,7)
#12
print('Exercise 12')
listNo=[]
input_num = int(input("How many numbers do you want to enter"))
for n in range(input_num):
    num=int(input("Enter Number: "))
    listNo.append(num)
print("Smallest is =", min(listNo),"\nLargest is =", max(listNo))

#13
print('Exercise 13')
def printAverage():
    sum=0
    counter=0
    inputnum = int(input('Enter a positive number:'))
    while inputnum >= 0:
         counter=counter+1
         sum=sum+inputnum
         inputnum=int(input('Enter a positive number:') )
    avg=sum/counter 
    print('Your average is :',avg)
printAverage()
#14
print('Exercise 14')
def numUnique(x,y,z):
    count =0
    if x!=y:
        count=count+1
    if y!=z:
        count=count+1
    if x!=z:
        count=count+1
    if x==y and y==z:
        count=count+1
    return count
print(numUnique(18,3,4))
#15
print('Exercise 15')
import random
tries=0
sum=0
while sum!=7:
    roll1=random.randint(1,6)+1
    roll2=random.randint(1,6)+1
    sum=roll1+roll2
    print(roll1, '+', roll2, '=', sum)
    tries+=1

print("You won after " ,tries,"tries")

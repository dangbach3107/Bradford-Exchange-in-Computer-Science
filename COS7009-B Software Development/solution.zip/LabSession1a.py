#2
print('/ \\ // \\ /// \\\\\\')
#4
print('A \"quoted\" String is\n\
\'much\' better if you learn\n\
the rules of \"escape sequences.\"\n\
Also, \"\" represents an empty String.\n\
Don\'t forget: use \\\" instead of \" !\n\
\'\' is not the same as \"')

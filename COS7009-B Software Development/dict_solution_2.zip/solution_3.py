def add_word(word, word_set):
    '''Add the word to the set. No word smaller than length 3.'''
    if len(word) > 3:
        word_set.add(word)

import string
def process_line(line, word_set):
    '''Process the line to get lowercase words to be added to the set.'''
    line = line.strip()
    word_list = line.split()
    for word in word_list:
        # ignore the '--' that is in the file
        if word != '--':
            word = word.strip()
            # get commas, periods and other punctuation out as well
            word = word.strip(string.punctuation)
            word = word.lower()
            add_word(word, word_set)

def main ():
    '''Compare test1.txt and test2.txt.'''
    test1_set = set()
    test2_set = set()
    test1_file = open('test1.txt')
    test2_file = open('test2.txt')
    for line in test1_file:
        process_line(line, test1_set)
    for line in test2_file:
        process_line(line,test2_set)
    print(test1_set)
    print(test2_set)

if __name__ == "__main__":
         main()

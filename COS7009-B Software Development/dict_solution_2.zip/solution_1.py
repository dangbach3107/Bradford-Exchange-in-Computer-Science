def create_dict():
    file_obj=open('iris.txt','r')

    # initialize counts
    sep_len=0
    sep_wid=0
    pet_len=0
    pet_wid=0
    count=0

    # create dictionary
    iris_Dict={'setosa':0,'virginica':0,'versicolor':0}

    # for every key in the dictionary
    # run through every line, if line contains string from key
    # total all four values and keep a count
    # divide totals by count
    # reset values for next key
    # store in dictionary
    for key,value in iris_Dict.items():
        for line in file_obj:
            line=line.strip()
            line=line.split(',')
            if key in line[4]:
                sep_len+=float(line[0])
                sep_wid+=float(line[1])
                pet_len+=float(line[2])
                pet_wid+=float(line[3])
                count+=1
            else:
                break
        sep_len_avg=sep_len/count
        sep_wid_avg=sep_wid/count
        pet_len_avg=pet_len/count
        pet_wid_avg=pet_wid/count
        sep_len,sep_wid,pet_len,pet_wid,count=0,0,0,0,0
        iris_Dict[key]=[sep_len_avg,sep_wid_avg,pet_len_avg,pet_wid_avg]
    return iris_Dict

def pretty_print(iris_Dict):
    for k,v in iris_Dict.items():
        print("{:11s}:".format(k),end=' ')
        for i in v:
            print("{:6.3f}".format(i),end=' ')
        print()

iris_dict = create_dict()
pretty_print(iris_dict)

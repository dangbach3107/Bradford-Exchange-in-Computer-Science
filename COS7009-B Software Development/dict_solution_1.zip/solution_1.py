
D = {'a':3,'x':7,'r':5}

# a
print(D['x'])

# b
for key,value in list(D.items()):
    if value == 7:
        print(key)
        break



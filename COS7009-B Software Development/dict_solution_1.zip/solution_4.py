
myDict = {'a':15,'c':35,'b':20}

# a
print("Keys:",end = ' ')
for k in myDict:  # or myDict.keys()
    print(k, end=' ')
print()

# b
print("Values:",end = ' ')
for v in list(myDict.values()):
    print(v, end=' ')
print()
# c
print("Key-Value pairs")
for k,v in list(myDict.items()):
    print(k,v)
print()
# d
print(sorted([(k,v) for k,v in list(myDict.items())]))

# e
print(sorted([(v,k) for k,v in list(myDict.items())]))

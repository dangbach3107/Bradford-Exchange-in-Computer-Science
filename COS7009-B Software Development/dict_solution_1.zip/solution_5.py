# Letter counts using dictionaries

def common(in_str):
    '''Return the most common letter in string in_str.'''
    # count letters
    letter_count_dict = {}
    for ch in in_str:
        if ch != ' ':
            if ch in letter_count_dict:
                letter_count_dict[ch]+= 1
            else:
                letter_count_dict[ch]=1
    # find most common by making a reversed list of (count,letter) tuples
    letter_count_list = []
    for letter,count in list(letter_count_dict.items()):
        letter_count_list.append((count,letter))
    # find the max count
    count,letter = max(letter_count_list)
    return letter
    
def counts(in_str):
    '''Return a dictionary of letters and counts in in_str.'''
    # count letters
    letter_count_dict = {}
    for ch in in_str:
        if ch != ' ':
            if ch in letter_count_dict:
                letter_count_dict[ch]+= 1
            else:
                letter_count_dict[ch]=1
    return letter_count_dict

def histogram(in_str):
    '''Print a histogram of letter counts in string in_str.'''
    # count letters
    letter_count_dict = counts(in_str)

    # alphabetize (letter,count) tuples
    letter_count_list = []
    for letter,count in list(letter_count_dict.items()):
        letter_count_list.append((letter,count))
    letter_count_list.sort()

    for letter,count in letter_count_list:
        print(letter, end=' ')
        for i in range(count):
            print('*', end=' ')
        print()
        

# First and Last name character manipulation

def common1(first_str, last_str):
    '''Return a list of common letters in first_str and last_str.'''
    common = []

    for ch in first_str:
        if ch in last_str and ch not in common:
            common.append(ch)

    return common

def common2(first_str, last_str):
    '''Return a set of common letters in first_str and last_str.'''
    common = set([])

    for ch in first_str:
        if ch in last_str:
            common.add(ch)

    return common

def common3(first_str, last_str):
    '''Return symmetric difference of letters in first_str and last_str.'''

    first_set = set(first_str)
    last_set = set(last_str)
    return first_set.symmetric_difference(last_set)

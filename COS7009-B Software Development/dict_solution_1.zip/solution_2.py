# zip

firstList = ['Jane', 'John', 'Jack']
lastList = ['Doe', 'Deer', 'Black']

D = dict(list(zip(firstList,lastList)))

print(D)


mySet = set('bcd')
yourSet = set('abcde')

# a
print(mySet.issubset(yourSet))

# b
print(yourSet.issubset(mySet))
